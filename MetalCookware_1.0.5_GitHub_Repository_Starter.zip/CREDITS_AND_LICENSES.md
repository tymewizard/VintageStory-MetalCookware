# Metal Cookware — Credits, provenance, and license notices

**Release:** 1.0.4 for Vintage Story 1.22.7  
**Mod ID:** `mc`  
**Creator / project maintainer:** **tymewizard**

## Project identity

Metal Cookware is a separately named and maintained mod with its own `mc` namespace. Its design builds on metal tableware and cooking systems developed by earlier mod authors. Naming this project Metal Cookware, using a new mod ID, or calling it a 1.0 release does **not** transfer copyright ownership of incorporated upstream material.

## Inspiration and acknowledgments

- **Pewter** — Zach2039; contribution credits include DeanBro.
- **Pewter Additions: Brass, Electrum, and Gold/Silver** — original releases and their credited creators, including Zach2039.
- **Pewter Additions: Bismuth** — kida_mei.
- **Pewter Additions: Copper and Nickel** — bluestar_ (per source archive provenance).
- **Metal Cooking Pots** — ApolloxYT / Yoldovahkriid.

These projects are not merely abstract inspirations: this package contains or adapts upstream code, recipes, textures, models, patches, or other assets. Credit is not a substitute for license permission. No upstream author's endorsement is implied.

## License and reuse

**tymewizard's original additions, new integration material, documentation, and modifications (where tymewizard owns the rights) are offered under the MIT license** in `LICENSE_TYMEWIZARD_MIT.txt`. Forking, modification, public redistribution, and commercial redistribution of those portions are permitted under MIT terms.

**Third-party materials retain their own licenses and rights and are not sublicensed by this declaration:**

- Pewter upstream materials: CC0-1.0 is documented in `LICENSE_PEWTER_CC0.txt`. See https://github.com/zach2039/vs-pewter.
- Metal Cooking Pots materials: MIT, copyright (c) 2025 ApolloxYT. Preserve `THIRD_PARTY_LICENSES/METALPOTS_MIT.txt` when redistributing.
- Bismuth and Copper/Nickel addon materials: independently verified reuse/redistribution authorization has **not** been established by the current project audit; acquire permission or verify a permissive license before a public redistribution containing those assets.
- Other contributed artwork, audio, and textures: their licenses and authorship should be verified before public release if derived from third-party sources.

The mod as packaged therefore **cannot be described as wholly MIT-licensed or wholly original** until all third-party rights are cleared. Downstream redistributors must comply with the applicable licenses for each component.

## AI-assisted development

AI (ChatGPT by OpenAI) was used for code/asset inspection, assistance with troubleshooting, suggested changes, documentation, and packaging. The human creator and maintainer is tymewizard. No AI system is represented as a copyright owner or project author.

## Game compatibility and migration

This public release is version **1.0.4**, for **Vintage Story 1.22.7**, using mod ID `mc`. It does not include the temporary Pewter-to-`mc` remapping configuration or mappings for removed `metalpots:` content. Players moving existing worlds from those mods must back up their saves and handle any needed ID migration separately.
